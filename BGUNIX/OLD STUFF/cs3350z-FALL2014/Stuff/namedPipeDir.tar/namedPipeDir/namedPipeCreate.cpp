#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <string.h>
#include <iostream> 

int main (int argc, char *argv[]) {
  int descriptor; 
  mknod ( argv[1], S_IWUSR|S_IRUSR|S_IFIFO, 0 );
}



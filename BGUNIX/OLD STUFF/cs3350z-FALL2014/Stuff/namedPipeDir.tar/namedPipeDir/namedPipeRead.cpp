#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#include <string.h>
#include <iostream> 

int main (int argc, char *argv[]) {
  int descriptor; 

  char buf [123];

  descriptor = open ( argv[1], O_RDONLY ); 
  read ( descriptor, buf, 123 ); 
  printf ( "%s\n", buf ); 
  read ( descriptor, buf, 123 ); 
  printf ( "%s\n", buf ); 
  close (descriptor);
} 


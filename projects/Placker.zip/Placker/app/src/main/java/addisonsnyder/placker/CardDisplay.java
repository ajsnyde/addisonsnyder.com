package addisonsnyder.placker;

import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import java.util.ArrayList;

import readPlicker.Card;

/**
 * Created by Dreadhawk on 10/26/2016.
 */
public class CardDisplay extends View {
    Paint paint = new Paint();
    int totalWidth;
    int width;
    int cardNum = 0;
    final int BORDER = 30;
    public ArrayList<Card> cards;
    public Card card;
    boolean test = false;
    int refreshDelay = 400;




    public CardDisplay(Context context) {
        super(context);
    }

    @Override
    public void onDraw(Canvas canvas) {

        totalWidth = 1080;
        width = (totalWidth - (2 * BORDER))/5;

        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);

        if(test) {
            drawSquare(canvas, 0, 0);
            drawSquare(canvas, 1, 1);
            drawSquare(canvas, 2, 2);
            drawSquare(canvas, 3, 3);
            drawSquare(canvas, 4, 4);
        }else{
            for (int i = 0; i < 5; ++i)
                for (int j = 0; j < 5; ++j){
                    if(card.values[i][j])
                        drawSquare(canvas, i,j);
                }
        }
    }

    Handler handler = new Handler(Looper.getMainLooper());
    public Runnable startLoop = new Runnable(){
        public void run(){
            card = cards.get(cardNum%cards.size());
            cardNum++;
            invalidate(); //will trigger onDraw()
            handler.postDelayed(this, refreshDelay);
        }
    };

    public void drawSquare(Canvas canvas, int x, int y){
        canvas.drawRect((BORDER + (x*width)), BORDER + (y*width), totalWidth - ((4-x)*width) - BORDER, totalWidth - ((4-y)*width) - BORDER, paint );
    }
}

package addisonsnyder.placker;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import readPlicker.Card;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        ArrayList<Card> list = new ArrayList<Card>();
        try {
            InputStream stream = getAssets().open("cards.ser");
            ObjectInputStream is = new ObjectInputStream(stream);
            list = (ArrayList<Card>) is.readObject();
            is.close();
            list.get(1).display();
        } catch (IOException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        super.onCreate(savedInstanceState);
        CardDisplay cardDisplay;
        cardDisplay = new CardDisplay(this);
        cardDisplay.card = list.get(2);
        cardDisplay.cards = list;
        cardDisplay.setBackgroundColor(Color.WHITE);
        cardDisplay.startLoop.run();
        setContentView(cardDisplay);
    }
}

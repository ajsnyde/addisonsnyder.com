package addisonsnyder.readPlicker;

import java.io.Serializable;

public class Card implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 4159387981317612406L;
    // 5x5 matrix with 'A' side up - rotating counterclockwise would give you
    // 'B', then 'C', and so on.
    public boolean[][] values = null;
    Side side;

    public enum Side {
        A, B, C, D
    }

    Card(boolean[][] values) {
        this.values = values;
    }

    Card(boolean[][] values, int face) {
        if (face > 1)
            values = rotateMatrixRight(values);
        if (face > 2)
            values = rotateMatrixRight(values);
        if (face > 3)
            values = rotateMatrixRight(values);
        this.values = values;
        side = Side.A;
    }

    public void display() {
        for (boolean[] array : values) {
            for (boolean value : array)
                System.out.print(value ? "#" : " ");
            System.out.println("");
        }
        System.out.println("~~~~~");
    }

    public boolean[][] rotateMatrixLeft(boolean[][] matrix) {
		/* W and H are already swapped */
        int w = matrix.length;
        int h = matrix[0].length;
        boolean[][] ret = new boolean[h][w];
        for (int i = 0; i < h; ++i) {
            for (int j = 0; j < w; ++j) {
                ret[i][j] = matrix[j][h - i - 1];
            }
        }
        return ret;
    }

    public boolean[][] rotateMatrixRight(boolean[][] matrix) {
		/* W and H are already swapped */
        int w = matrix.length;
        int h = matrix[0].length;
        boolean[][] ret = new boolean[h][w];
        for (int i = 0; i < h; ++i) {
            for (int j = 0; j < w; ++j) {
                ret[i][j] = matrix[w - j - 1][i];
            }
        }
        return ret;
    }
}

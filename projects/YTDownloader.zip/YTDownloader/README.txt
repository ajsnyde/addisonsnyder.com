YTDownloader
By Addison Snyder

Built 11/26/16
Source available here: https://github.com/ajsnyde/YTDownloader

HOW TO USE
~~~~~~~~~~~~~~~~~~~
0. Extract YTDownloader folder from .zip file
1. Ensure that JRE 1.8 or higher is installed - 1.7 is untested but might work
2. Start program (YTDownloader)
3. Paste Youtube urls into program using Ctrl+V
4. Metadata should be opened in a new window - while not all features are currently operational,
download, conversion, and splitting should work.

Splitting
	- Requires a description containing a list of songnames and timestamps
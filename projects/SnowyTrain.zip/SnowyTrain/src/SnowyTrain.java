

/*  A snowy train scene/animation
 * 
 *  The animation(and amount of snow) automatically rescales as the window size changes
 *  PaintComponent uses getWidth, getHeight to accomplish this.
 * 
 * Uses Java Graphics to draw a picture.
 * Main visual components:
 * 	  Canvas:     Inherits from JPanel,
 * 				  uses SnowParticle for snow
 *                All graphics are drawn by paintComponent
 *    ButtonPanel:  Houses all the buttons
 *    
 *    A separate class, ButtonHandler, is used to listen for button events
 *    Mouse events are handled by the STCanvas instance: displayPanel
 *
 * 		
 * 
 * Features:  
 *      Primitives:  Oval, rectangle, polygon
 *      Attributes:  Color, WindX, Density of snow, various booleans for statuses
 *      
 */

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class SnowyTrain {

	public static JPanel displayPanel;      // graphics are drawn here
	public static boolean run = false;
	public static boolean trainrun = false;
	static boolean SnowVisible;
	double windX = 0;
	static int DENSITY = 500;
	static ArrayList<SnowParticle> Snow = new ArrayList<SnowParticle>();
	static int run2 = 1;
	static int trainY, frostyDir;   // frosty's X coordinate and Direction
	
	public static class Canvas extends JPanel {
		// all drawing on this canvas is auto-scaled
		// based on current size.
		
		public void paintComponent(Graphics g){
			super.paintComponent(g);

			int w = getWidth();
			int h = getHeight();
			mySkyLine(g,w,h);
			drawTrainTracks(g,w,h);
			if(run){
				if(trainrun)
					trainY += run2;
				displayPanel.repaint();}
			Train(g,trainY,w,h);
			updateSnow(g,w,h);
			if (SnowVisible)
				for(int i = 0; i < Snow.size(); i++)
					Snow.get(i).draw(g);
		}
		public void mySkyLine(Graphics g, int w, int h) {

			g.setColor(new Color(102,102,255));  // very light blue
			g.fillRect(0,0,w, h/2);  // the sky
			g.setColor(new Color(102,255,102)); // light green
			g.fillRect(0,h/2, w, (int)(2.0*h/2));

		}
		public void drawTrainTracks(Graphics g, int w, int h){
			g.setColor( new Color(50,50,50));
			g.fillRect(0,60*h/100, w, h/200);
			g.fillRect(0,65*h/100, w, h/200);
			for(int i = 1; i < 12; i++){
				g.fillRect(i*(w/12),60*h/100, w/200, h/20 + h/200);
			}

		}
		public void updateSnow(Graphics g, int w, int h){
			if(DENSITY == -1){
				Snow.clear();
				return;
			}
			if(Math.random() < .2)
				SnowParticle.chgWind(.25);

			if(Snow.size() < ((w*h)/DENSITY))
				for(int i = 0; i < 500; i++)
					Snow.add(new SnowParticle((Math.random()*2*w) - (.5*w), Math.random()*h));
			else if(Snow.size() > (w*h)/DENSITY)
				while(Snow.size() > (w*h)/DENSITY)
					Snow.remove(Snow.size()-1);
			else{
				for(int i = 0; i < Snow.size(); i++){
					Snow.get(i).updateLoc(w, h);
					if(Snow.get(i).isDead)
						Snow.set(i, new SnowParticle((Math.random()*2*w) - (.5*w), Math.random()*-25));
				}
			}
		}
		public void Train( Graphics g, int moveX, int w, int h){
			g.setColor(Color.DARK_GRAY);
			g.fillRect((int)((moveX%(w*1.4))-(w*.2)),55*h/100,w/10, h/10);
		}
	}


	/* handles all button presses */
	private static class ButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			String aC = e.getActionCommand();
			if ( aC.equals("Move Train")) {
				if(!trainrun){
					run2++;
					trainrun = true;
				}
				else{
					trainrun = false;
					run2 = 0;
				}

				trainY += run2;
				displayPanel.repaint();
			}
			else if ( aC.equals("Toggle Run")){
				if ( run) 
					run = false;
				else 
					run = true;
				SnowVisible = !SnowVisible;
				displayPanel.repaint(); // ask event loop to call PaintComponent
			}
			else if ( aC.equals("Toggle Snow")){
				if(DENSITY != -1)
					DENSITY = -1;
				else
					DENSITY = 300;
			}
			else if (aC.equals("Change Wind"))
			{
				SnowParticle.chgWind(2);
			}
			else if (aC.equals("Change Density"))
				DENSITY = (int) ((Math.random()*600) + 50);
			else if (aC.equals("Exit"))
				System.exit(0);
		}
	}
	public static void main(String[] args) {

		displayPanel = new Canvas();

		JButton B1B = new JButton("Toggle Run");
		JButton B2B = new JButton("Move Train");
		JButton B3B = new JButton("Toggle Snow");
		JButton B4B = new JButton("Change Wind");
		JButton B5B = new JButton("Change Density");
		JButton B6B = new JButton("Exit");
		ButtonHandler listener = new ButtonHandler();
		B1B.addActionListener(listener);
		B2B.addActionListener(listener);
		B3B.addActionListener(listener);
		B4B.addActionListener(listener);
		B5B.addActionListener(listener);
		B6B.addActionListener(listener);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout( new FlowLayout() );
		buttonPanel.add(B1B);
		buttonPanel.add(B2B);
		buttonPanel.add(B3B);
		buttonPanel.add(B4B);
		buttonPanel.add(B5B);
		buttonPanel.add(B6B);
		JPanel content = new JPanel();
		content.setLayout(new BorderLayout());
		content.add(displayPanel, BorderLayout.CENTER);
		content.add(buttonPanel, BorderLayout.SOUTH);

		trainY = 20;
		frostyDir = 1;
		SnowVisible = false;

		
		
		JFrame window = new JFrame("Addison Snyder - Snowy Train");
		window.setContentPane(content);
		window.setSize(800,600);
		window.setLocation(100,100);
		window.setVisible(true);
		

	}
}

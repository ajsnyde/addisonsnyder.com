import java.awt.Color;
import java.awt.Graphics;


/*							ADDISON SNYDER
 * 		SnowParticle contains data for an individual snowflake:
 * 			Size
 * 			base velocity
 * 			death status
 * 			
 * 		Additionally, static variables are held that can change the attributes of the entire blizzard (e.g. horizontal windspeed)
 */

public class SnowParticle {
	private double x, y, vX, vY;
	private int size = (int)(Math.random()*5);
	public boolean  isDead = false;
	static double wX = 0;

	Color color = new Color(255,255,255);
	
	public SnowParticle()
	{
		this.x = Math.random()*400;
		this.y = -Math.random()*10;
		vX = 0;
		vY = 1;
	}
	
	public SnowParticle( int x, int y)
	{
		this.x = x;
		this.y = y;
		vX = .5;
		vY = -1.5;
	}
	
	public SnowParticle( double x, double y)
	{
		this.x = x;
		this.y = y;
		vX = .5 + (Math.random()*1)-.25;
		vY = -1.5 + (Math.random()*.5)-.25;
	}
	
	public SnowParticle( double x, double y, double vX, double vY)
	{
		this.x = x;
		this.y = y;
		this.vX = vX;
		this.vY = vY;
	}
	
	public void draw(Graphics g)
	{
		if(isDead)
			return;
		g.setColor(color);  // white
		g.fillOval((int)x, (int)y, size, size);  // the snowflake is drawn
	}
	public void updateLoc(int w, int h)
	{
		if(wX > 3)
			wX--;
		if(wX < -3)
			wX++;
		x += vX + wX;
		y -= vY;
		if(x < (-1.0/2)*w || x > w *1.5)
			isDead = true;
		if(y < -10 || y > h + 10)
			isDead = true;
	}

	public static void chgWind(double mag){
		wX += (Math.random()*mag)-(mag/2);
	}
	public static double getWind(){
		return wX;
	}
}


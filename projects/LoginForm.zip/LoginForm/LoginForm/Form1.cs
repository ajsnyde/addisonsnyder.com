﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginForm
{
    
    public partial class Form1 : Form
    {
        int attempts = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string password = textBox2.Text;
            attempts++;

            if (attempts > 5)
            {
                LockOut locker = new LockOut();
                locker.Show();
                textBox3.Text = "Out of attempts!";
                return;
            }

            // send to server...
            // get result back

            if (user == "Addison" && password == "Snyder")
            {
                AboutBox1 next = new AboutBox1();
                next.Show();
                
            }
            else
                textBox2.Text = "";
        }
    }
}

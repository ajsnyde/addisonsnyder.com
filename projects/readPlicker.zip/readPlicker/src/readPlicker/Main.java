package readPlicker;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		jpgToMatrix test = new jpgToMatrix();
		test.getFromFiles();

		ArrayList<Card> list = new ArrayList<Card>();

		try {
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("Cards"));
			list = (ArrayList<Card>) ois.readObject();
			ois.close();
		} catch (IOException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(list.size());
		list.get(5).display();
	}
}

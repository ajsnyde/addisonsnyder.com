package readPlicker;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;

public class jpgToMatrix {

	ArrayList<Card> getFromFiles() {
		ArrayList<Card> cards = new ArrayList<Card>();

		String filename;
		BufferedImage img;
		Card card;
		for (int i = 0; i < 16; ++i) {
			filename = "2016-10-26 22_04_" + (i + 13) + "-PlickersCards_2up.pdf - Adobe Acrobat Reader DC.jpg";
			img = readImage(filename);

			System.out.println(filename);

			// 1=A, 2=B, so on..
			int[] faces = new int[] { 2, 4, 4, 4, 1, 1, 1, 2, 1, 4, 4, 1, 3, 4, 1, 2, 4, 3, 4, 4, 2, 2, 3, 4, 4, 2, 3,
					2, 3, 2, 2, 3 };

			boolean[][] card1 = new boolean[][] {
					{ isBlack(img, 300, 220), isBlack(img, 350, 220), isBlack(img, 390, 220), isBlack(img, 437, 220),
							isBlack(img, 483, 220) },
					{ isBlack(img, 300, 270), isBlack(img, 350, 270), isBlack(img, 390, 270), isBlack(img, 437, 270),
							isBlack(img, 483, 270) },
					{ isBlack(img, 300, 315), isBlack(img, 350, 315), isBlack(img, 390, 315), isBlack(img, 437, 315),
							isBlack(img, 483, 315) },
					{ isBlack(img, 300, 360), isBlack(img, 350, 360), isBlack(img, 390, 360), isBlack(img, 437, 360),
							isBlack(img, 483, 360) },
					{ isBlack(img, 300, 400), isBlack(img, 350, 400), isBlack(img, 390, 400), isBlack(img, 437, 400),
							isBlack(img, 483, 400) } };

			card = new Card(card1, faces[2 * i]);
			System.out.println(faces[2 * i]);
			card.display();
			cards.add(card);

			boolean[][] card2 = new boolean[][] {
					{ isBlack(img, 300, 582), isBlack(img, 350, 582), isBlack(img, 390, 582), isBlack(img, 437, 582),
							isBlack(img, 483, 582) },
					{ isBlack(img, 300, 630), isBlack(img, 350, 630), isBlack(img, 390, 630), isBlack(img, 437, 630),
							isBlack(img, 483, 630) },
					{ isBlack(img, 300, 675), isBlack(img, 350, 675), isBlack(img, 390, 675), isBlack(img, 437, 675),
							isBlack(img, 483, 675) },
					{ isBlack(img, 300, 720), isBlack(img, 350, 720), isBlack(img, 390, 720), isBlack(img, 437, 720),
							isBlack(img, 483, 720) },
					{ isBlack(img, 300, 765), isBlack(img, 350, 765), isBlack(img, 390, 765), isBlack(img, 437, 765),
							isBlack(img, 483, 765) } };

			card = new Card(card2, faces[(2 * i) + 1]);
			System.out.println(faces[(2 * i) + 1]);
			card.display();
			cards.add(card);
		}

		try {
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("Cards"));
			oos.writeObject(cards);
			oos.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cards;
	}

	BufferedImage readImage(String filename) {
		BufferedImage img = null;
		try {
			img = ImageIO.read(new File(filename));
		} catch (Exception e) {
		}
		return img;
	}

	boolean isBlack(BufferedImage image, int x, int y) {
		int pixel = image.getRGB(x, y);
		Color col = new Color(pixel);
		if (col.getRed() == 17 && col.getGreen() == 17 && col.getBlue() == 17)
			return true;
		else
			return false;
	}
}
